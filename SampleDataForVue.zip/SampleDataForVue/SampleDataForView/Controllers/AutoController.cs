﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;

namespace SampleDataForVue.Controllers
{
    [Route("api/[controller]")]
    [EnableCors("AllowSpecificOrigin")]
    public class AutoController : Controller
    {

        [HttpGet("[action]")]
        public IEnumerable<Auto> AutoList()
        {
            Auto[] autos = new Auto[]
            {
                new Auto { Brand="Nissan", Model="Rogue", Color="Red" },
                new Auto { Brand="Toyota", Model="Camry", Color="Black" },
                new Auto { Brand="Honda", Model="Accord", Color="Silver" }
            };

            return autos;

        }


        public class Auto
        {
            public string Brand { get; set; }
            public string Model { get; set; }
            public string Color { get; set; }

        }
    }
}







